<footer class="content-footer footer bg-footer-theme">
    <div class="container-xxl">
        <div
        class="footer-container d-flex align-items-center justify-content-between py-2 flex-md-row flex-column">
        <div>
            © {{ date('Y') }}, made with ❤️ by <a href="javascript:void(0)" class="fw-medium">{{ config('constants.site_title') }}</a>
        </div>
        </div>
    </div>
</footer>