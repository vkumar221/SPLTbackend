<link rel="icon" href="{{ asset(config('constants.admin_path').'images/favicon.svg') }}" type="image/x-icon" />
<!-- [Font] Family -->
<link rel="stylesheet" href="{{ asset(config('constants.admin_path').'fonts/inter/inter.css')}}" id="main-font-link" />
<!-- [phosphor Icons] -->
<link rel="stylesheet" href="{{ asset(config('constants.admin_path').'fonts/phosphor/duotone/style.css')}}" />
<!-- data tables css -->
<link rel="stylesheet" href="{{ asset(config('constants.admin_path').'css/plugins/dataTables.bootstrap5.min.css')}}" />
<!-- [Tabler Icons] -->
<link rel="stylesheet" href="{{ asset(config('constants.admin_path').'fonts/tabler-icons.min.css')}}" />
<!-- [Feather Icons] -->
<link rel="stylesheet" href="{{ asset(config('constants.admin_path').'fonts/feather.css')}}" />
<!-- [Font Awesome Icons] -->
<link rel="stylesheet" href="{{ asset(config('constants.admin_path').'fonts/fontawesome.css')}}" />
<!-- [Material Icons] -->
<link rel="stylesheet" href="{{ asset(config('constants.admin_path').'fonts/material.css')}}" />
<!-- [Template CSS Files] -->
<link rel="stylesheet" href="{{ asset(config('constants.admin_path').'css/style.css')}}" id="main-style-link" />
<link rel="stylesheet" href="{{ asset(config('constants.admin_path').'css/style-preset.css')}}" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert2/11.10.1/sweetalert2.min.css">

